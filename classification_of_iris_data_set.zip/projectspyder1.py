# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 05:11:43 2018

@author: Sasank
"""

#import desired packages
import tensorflow as tf
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
data=pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data', names=['f1','f2','f3','f4','f5'])
print (data)
print(data["f5"].value_counts())
print(sns.FacetGrid(data, hue="f5", height=5) \
   .map(plt.scatter, "f1", "f2") \
   .add_legend())
#map data into arrays
s=np.asarray([1,0,0])
ve=np.asarray([0,1,0])
vi=np.asarray([0,0,1])
data['f5'] = data['f5'].map({'Iris-setosa': s, 'Iris-versicolor': ve,'Iris-virginica':vi})
print(data)

#shuffle the data
data=data.iloc[np.random.permutation(len(data))]
print(data)
#indexing properly
data=data.reset_index(drop=True)
print(data)

#training data
x_input=data.loc[0:105,['f1','f2','f3','f4']]#taking 0 to 105 as input
temp=data['f5']
y_input=temp[0:106]#taking 0 to 106 as output
print(x_input)
print(y_input)
#test data
x_test=data.loc[106:149,['f1','f2','f3','f4']]
y_test=temp[106:150]
#placeholders and variables. input has 4 features and output has 3 classes
x=tf.placeholder(tf.float32,shape=[None,4])
y_=tf.placeholder(tf.float32,shape=[None, 3])
#weight and bias
W=tf.Variable(tf.zeros([4,3]))
b=tf.Variable(tf.zeros([3]))
# model 
#softmax function for multiclass classification
y = tf.nn.softmax(tf.matmul(x, W) + b)
#loss function
cross_entropy = tf.reduce_mean(-tf.reduce_sum(y_ * tf.log(y), reduction_indices=[1]))

#optimiser -
train_step = tf.train.AdamOptimizer(0.01).minimize(cross_entropy)
#calculating accuracy of our model 
correct_prediction = tf.equal(tf.argmax(y,1), tf.argmax(y_,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

#session parameters
sess = tf.InteractiveSession()
#initialising variables
init = tf.initialize_all_variables()
sess.run(init)
#number of interations
epoch=2000

for step in range(epoch):
    _,c=sess.run([train_step,cross_entropy], feed_dict={x: x_input, y_:[t for t in y_input.values]})
    if(step%100==0):
        print("Epoch :",step," Cost: ",c )


#random testing at Sn.130
a=data.loc[140,['f1','f2','f3','f4']]
b=a.values.reshape(1,4)
largest = sess.run(tf.arg_max(y,1), feed_dict={x: b})[0]
if largest==0:
    print ("flower is :Iris-setosa")
elif largest==1:
    print ("flower is :Iris-versicolor")
else :
    print ("flower is :Iris-virginica")
print (sess.run(accuracy,feed_dict={x: x_test, y_:[t for t in y_test.values]}))